import java.util.Date;

public class Student implements Comparable {

	private int id;
	private String fullName;
	private Date birthDate;
	private double avgMark;

	public Student(int id, String fullName, Date birthDate, double avgMark) {

	}

	public int getId() {

	}

	public void setId(int id) {

	}

	public String getFullName() {

	}

	public void setFullName(String fullName) {

	}

	public Date getBirthDate() {

	}

	public void setBirthDate(Date birthDate) {

	}

	public double getAvgMark() {

	}

	public void setAvgMark(double avgMark) {

	}

	@Override
	public boolean equals(Object o) {

	}

	@Override
	public int hashCode() {

	}

	@Override
	public int compareTo(Object o) {

	}
}